import fs from 'fs'

let handler = async (m, { conn }) => {
  // Ambil nomor pengirim tanpa @s.whatsapp.net
  const senderNumber = m.sender.split('@')[0]
  
  // Format ID sesi yang sama dengan yang ada di file auto-ai kamu
  const sid = `${m.chat}:${senderNumber}`

  // Pastikan global object-nya ada
  if (!global.aiSessions) global.aiSessions = {}

  if (global.aiSessions[sid]) {
    // Hapus histori user dari memori
    delete global.aiSessions[sid]
    
    try {
      // Langsung simpan perubahan ke file JSON biar langsung kereset permanen
      await fs.promises.writeFile('./ai_sessions.json', JSON.stringify(global.aiSessions, null, 2))
      
      // Balasan khas Anya buat owner
      m.reply('Siap Dev! Ingatan Anya buat obrolan kita udah di-reset yaa. Mau bahas apa sekarang? Waku waku! ><')
    } catch (err) {
      console.error('Gagal mereset JSON:', err)
      m.reply('Ehh.. ada yang error pas Anya mau ngelupain chatnya. Coba cek console ya Dev!')
    }
  } else {
    m.reply('Heh? Kita kan belum ada ngobrol akhir-akhir ini ehehe~')
  }
}

// Sesuaikan command-nya
handler.help = ['resetchat']
handler.tags = ['ai']
handler.command = /^(resetchat)$/i

// FITUR OWNER ONLY
handler.owner = true 

export default handler