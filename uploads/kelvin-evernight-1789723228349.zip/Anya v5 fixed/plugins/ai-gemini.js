import MB from 'baileys-mbuilder'

function parseAIResponse(text) {
    const blocks = []
    const lines = String(text || '').split('\n')
    let i = 0

    while (i < lines.length) {
        const line = lines[i]

        // Code Block
        if (line.trim().startsWith('```')) {
            const lang = line.trim().slice(3).trim() || 'javascript'
            const code = []

            i++
            while (
                i < lines.length &&
                !lines[i].trim().startsWith('```')
            ) {
                code.push(lines[i])
                i++
            }

            if (code.length) {
                blocks.push({
                    type: 'code',
                    lang,
                    content: code.join('\n')
                })
            }

            i++
            continue
        }

        // Markdown Table
        if (line.trim().startsWith('|')) {
            const tableLines = []

            while (
                i < lines.length &&
                lines[i].trim().startsWith('|')
            ) {
                tableLines.push(lines[i])
                i++
            }

            const rows = tableLines
                .filter(v => !/^\|[-| :]+\|$/.test(v.trim()))
                .map(v =>
                    v
                        .trim()
                        .replace(/^\||\|$/g, '')
                        .split('|')
                        .map(x => x.trim())
                )

            if (rows.length >= 2) {
                blocks.push({
                    type: 'table',
                    data: rows
                })
            } else {
                blocks.push({
                    type: 'text',
                    content: tableLines.join('\n')
                })
            }

            continue
        }

        // Text
        const textLines = []

        while (
            i < lines.length &&
            !lines[i].trim().startsWith('```') &&
            !lines[i].trim().startsWith('|')
        ) {
            textLines.push(lines[i])
            i++
        }

        const content = textLines.join('\n').trim()

        if (content) {
            blocks.push({
                type: 'text',
                content
            })
        }
    }

    return blocks
}

let handler = async (m, { conn, text }) => {
    if (!text) return m.reply('Masukkan pertanyaan!')

    await m.react('🕒')

    try {
        const res = await fetch(
            'https://www.puruboy.kozow.com/api/ai/gemini-v2',
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    prompt: text
                })
            }
        )

        const data = await res.json()

        if (!data.success)
            return m.reply('Gagal mendapatkan respons!')

        const ownerPP = await conn
            .profilePictureUrl(conn.user.jid, 'image')
            .catch(() => '')

        const parsed = parseAIResponse(data.result.answer)

        const rich = new MB.AIRich(conn)

        rich.setTitle('Gemini AI')

        for (const block of parsed) {

            switch (block.type) {

                case 'text':
                    rich.addText(block.content)
                    break

                case 'code':
                    rich.addCode(
                        block.lang,
                        block.content
                    )
                    break

                case 'table':
                    rich.addTable(block.data)
                    break

            }

        }

        rich.addSource([
    [
        String(ownerPP || ''),
        'https://wa.me/6281991861685',
        String(global.wm2 || 'Owner Bot')
    ],
    [
        'https://cdn.brandfetch.io/idnOT0K6yL/w/400/h/400/theme/dark/icon.png',
        'https://gemini.google.com',
        'Gemini AI'
    ]
])

        await rich.send(m.chat, {
            quoted: m
        })

        await m.react('✅')

    } catch (e) {

        console.error(e)

        await m.react('❌')
        await m.reply(e.message)

    }
}

handler.help = ['gemini']
handler.tags = ['ai']
handler.command = ['gemini', 'ai']

export default handler